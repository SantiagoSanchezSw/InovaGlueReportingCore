from django.apps import AppConfig


class GlueReportConfig(AppConfig):
    name = 'glue_report'
