from setuptools import setup, find_packages

setup(
    name="inova_glue_report_reporting_core",
    version="1.0",
    description="etl bi geo report for inova SAS",
    author="Santiago sanchez",
    packages=find_packages(),
    install_requires=[
        # Lista de dependencias de tu proyecto
    ],
    entry_points={},
)